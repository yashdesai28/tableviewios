//
//  cricketer.swift
//  tabletask
//
//  Created by bmiit on 06/03/24.
//

import Foundation

class criketer {
    
    var name:String
    var  age:Int
    var  number_matches:Int
    var  number_innings:Int
    var scored_runs:Int
    var number_notout:Int
    
    init(name:String,age:Int,number_matches:Int,number_innings:Int,scored_runs:Int,number_notout:Int) {
        self.name = name
        self.age = age
        self.number_matches = number_matches
        self.number_innings = number_innings
        self.scored_runs = scored_runs
        self.number_notout = number_notout
    }
    
    func edit(name:String,age:Int,number_matches:Int,number_innings:Int,scored_runs:Int,number_notout:Int){
        
    }
    
    func batingavg()-> Double{
        return Double(scored_runs)/Double(number_innings-number_notout)
    }
    
}
