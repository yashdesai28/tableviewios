//
//  TableViewController.swift
//  tabletask
//
//  Created by bmiit on 06/03/24.
//

import UIKit

class TableViewController: UITableViewController {
    @IBOutlet var agematch: UILabel!
    
    @IBOutlet var avgage: UILabel!
    @IBOutlet var number: UILabel!
    let products = ["yash","dev","vedu"];
    
    var cricketers : [criketer] = []
    
    var selectindex = -1;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        cricketers.insert(criketer(name: "virat", age: 20, number_matches: 20, number_innings: 12, scored_runs: 300, number_notout: 12),at:0)
        cricketers.insert(criketer(name: "sharma ji", age: 30, number_matches: 20, number_innings: 12, scored_runs: 3000, number_notout: 12),at:0)
        
        var nu = cricketers.count
        number.text = String(nu);
        
        avgage.text = "avg age:\(avg())"
        agematch.text = "avg age:\(avgmatch())"
        
        
        
        
       

      
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return cricketers.count
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectindex = indexPath.row
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mycell", for: indexPath)

        let crick = cricketers[indexPath.row];
      
        cell.textLabel?.text = crick.name
        cell.detailTextLabel?.text = "batingave : \(crick.batingavg())"
        
    

        return cell
    }
    
    public func avg() -> Double {
         
         let totalavg = cricketers.reduce(0,{$0 + $1.age})
         return Double(totalavg)/Double(cricketers.count)
     }
    
    public func avgmatch() -> Double {
         
        let totalavg = cricketers.reduce(0,{$0 + $1.number_matches})
         return Double(totalavg)/Double(cricketers.count)
     }
    
    
    @IBAction func addbtn(_ sender: Any) {
        
        let alertpop  = UIAlertController(title: "ENTER THE MATCH DETAILS", message: nil, preferredStyle:.alert)
        alertpop.addTextField{textfield in textfield.placeholder = "name"}
        
        alertpop.addTextField{textfield in textfield.placeholder = "age"}
        
        alertpop.addTextField{textfield in textfield.placeholder = "number of matches"}
        
        alertpop.addTextField{textfield in textfield.placeholder = "number of innings"}
        alertpop.addTextField{textfield in textfield.placeholder = "scored runs"}
        
        alertpop.addTextField{textfield in textfield.placeholder = "number of notout"}
        
        alertpop.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: {_ in}))
        
        alertpop.addAction(UIAlertAction(title: "Submit", style: UIAlertAction.Style.default, handler: {[self]_ in
            
            var name = alertpop.textFields?[0].text
            var  age = alertpop.textFields?[1].text
            var  number_matches = alertpop.textFields?[2].text
            var  number_innings = alertpop.textFields?[3].text
            var scored_runs = alertpop.textFields?[4].text
            var number_notout = alertpop.textFields?[5].text
            
            var age1 = Int(age!)
            var number_matches1 = Int(number_matches!)
            var number_innings1 = Int(number_innings!)
            var scored_runs1 = Int(scored_runs!)
            var number_notout1 = Int(number_notout!)
            
            let cricket1 = criketer(name: name ?? "",age: age1 ?? 0,number_matches: number_matches1 ?? 0,number_innings: number_innings1 ?? 0,scored_runs: scored_runs1 ?? 0,number_notout:number_notout1 ?? 0);
            
            cricketers.insert(cricket1, at: cricketers.endIndex);
            
            avgage.text = "avg age:\(avg())"
            agematch.text = "avg age:\(avgmatch())"
            var nu = cricketers.count
            number.text = String(nu);
            
            tableView.reloadData();
            
    
            
            
            
        }))
        
        self.present(alertpop, animated: true, completion:nil)
        
    }
    
    
    @IBAction func update(_ sender: Any) {
        
        let alertupdate = UIAlertController(title: "YOU CAN UPDATE", message: nil, preferredStyle:.alert)
        alertupdate.addTextField{[self] (textField) in textField.text = String(cricketers[selectindex].name)}
        alertupdate.addTextField{[self] (textField) in textField.text = String(cricketers[selectindex].age)}
        alertupdate.addTextField{[self] (textField) in textField.text = String(cricketers[selectindex].number_matches)}
        alertupdate.addTextField{[self] (textField) in textField.text = String(cricketers[selectindex].number_matches)}
        alertupdate.addTextField{[self] (textField) in textField.text = String(cricketers[selectindex].scored_runs)}
        alertupdate.addTextField{[self] (textField) in textField.text = String(cricketers[selectindex].number_notout)}
        
        alertupdate.addAction(UIAlertAction(title: "cancel", style: .default, handler: {_ in}))
        alertupdate.addAction(UIAlertAction(title: "submit", style: .default, handler: {[self]_ in
            
            var name =  alertupdate.textFields?[0].text
            var  age =  alertupdate.textFields?[1].text
            var  number_matches =  alertupdate.textFields?[2].text
            var  number_innings =  alertupdate.textFields?[3].text
            var scored_runs =  alertupdate.textFields?[4].text
            var number_notout =  alertupdate.textFields?[5].text
            
            var age1 = Int(age!)
            var number_matches1 = Int(number_matches!)
            var number_innings1 = Int(number_innings!)
            var scored_runs1 = Int(scored_runs!)
            var number_notout1 = Int(number_notout!)
            
            cricketers[selectindex].name = name!
            cricketers[selectindex].age = age1!
            cricketers[selectindex].number_matches = number_matches1!
            cricketers[selectindex].number_innings = number_innings1!
            cricketers[selectindex].scored_runs = scored_runs1!
            cricketers[selectindex].number_notout = number_notout1!
            avgage.text = "avg age:\(avg())"
            agematch.text = "avg age:\(avgmatch())"
            var nu = cricketers.count
            number.text = String(nu);
            
            tableView.reloadData();
            
            
            
        }))
        
        
        self.present(alertupdate, animated: true, completion: nil)
        
        
    }
    
    


    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
         
            cricketers.remove(at: indexPath.row)
            tableView.reloadData();
            
        }
    }
    
    
    @IBAction func updatedata(_ sender: Any) {
        
        
        
    }
    
    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
